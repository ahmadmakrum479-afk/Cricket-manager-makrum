package com.cricketmanager.app

import android.app.Application
import com.cricketmanager.app.data.local.CricketDatabase
import com.cricketmanager.app.data.repository.CricketRepository

class CricketManagerApplication : Application() {
    val database: CricketDatabase by lazy {
        CricketDatabase.getInstance(this)
    }

    val repository: CricketRepository by lazy {
        CricketRepository(database.cricketDao())
    }
}
