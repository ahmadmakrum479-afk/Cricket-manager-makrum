package com.cricketmanager.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.cricketmanager.app.data.local.MatchEntity
import com.cricketmanager.app.data.local.MatchStatus
import com.cricketmanager.app.data.local.TeamEntity

@Composable
fun MatchesScreen(
    matches: List<MatchEntity>,
    onTeamARuns: (MatchEntity, Int) -> Unit,
    onTeamAWicket: (MatchEntity) -> Unit,
    onTeamBRuns: (MatchEntity, Int) -> Unit,
    onTeamBWicket: (MatchEntity) -> Unit,
    onCompleteMatch: (MatchEntity) -> Unit,
    onDeleteMatch: (Long) -> Unit
) {
    if (matches.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "No fixtures yet. Tap + to schedule a cricket match.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        return
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(matches, key = { it.id }) { match ->
            MatchScoreCard(
                match = match,
                onTeamARuns = { runs -> onTeamARuns(match, runs) },
                onTeamAWicket = { onTeamAWicket(match) },
                onTeamBRuns = { runs -> onTeamBRuns(match, runs) },
                onTeamBWicket = { onTeamBWicket(match) },
                onComplete = { onCompleteMatch(match) },
                onDelete = { onDeleteMatch(match.id) }
            )
        }
    }
}

@Composable
private fun MatchScoreCard(
    match: MatchEntity,
    onTeamARuns: (Int) -> Unit,
    onTeamAWicket: () -> Unit,
    onTeamBRuns: (Int) -> Unit,
    onTeamBWicket: () -> Unit,
    onComplete: () -> Unit,
    onDelete: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${match.status.label} · ${match.oversLimit} Overs · ${match.venue}",
                    style = MaterialTheme.typography.labelMedium,
                    color = if (match.status == MatchStatus.LIVE) {
                        MaterialTheme.colorScheme.primary
                    } else {
                        MaterialTheme.colorScheme.onSurfaceVariant
                    }
                )
                IconButton(onClick = onDelete) {
                    Icon(
                        imageVector = Icons.Rounded.DeleteOutline,
                        contentDescription = "Delete match"
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            ScoreRow(
                teamName = match.teamAName,
                scoreText = "${match.teamAScore}/${match.teamAWickets}"
            )
            Spacer(modifier = Modifier.height(6.dp))
            ScoreRow(
                teamName = match.teamBName,
                scoreText = "${match.teamBScore}/${match.teamBWickets}"
            )

            if (match.resultSummary.isNotBlank()) {
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = match.resultSummary,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            if (match.status != MatchStatus.COMPLETED) {
                Spacer(modifier = Modifier.height(12.dp))
                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.25f))
                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "${match.teamAName} Scoring",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilledTonalButton(onClick = { onTeamARuns(1) }, modifier = Modifier.weight(1f)) { Text("+1") }
                    FilledTonalButton(onClick = { onTeamARuns(4) }, modifier = Modifier.weight(1f)) { Text("+4") }
                    FilledTonalButton(onClick = { onTeamARuns(6) }, modifier = Modifier.weight(1f)) { Text("+6") }
                    OutlinedButton(onClick = onTeamAWicket, modifier = Modifier.weight(1f)) { Text("W") }
                }

                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "${match.teamBName} Scoring",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilledTonalButton(onClick = { onTeamBRuns(1) }, modifier = Modifier.weight(1f)) { Text("+1") }
                    FilledTonalButton(onClick = { onTeamBRuns(4) }, modifier = Modifier.weight(1f)) { Text("+4") }
                    FilledTonalButton(onClick = { onTeamBRuns(6) }, modifier = Modifier.weight(1f)) { Text("+6") }
                    OutlinedButton(onClick = onTeamBWicket, modifier = Modifier.weight(1f)) { Text("W") }
                }

                Spacer(modifier = Modifier.height(10.dp))
                Button(
                    onClick = onComplete,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Rounded.CheckCircle, contentDescription = null)
                    Spacer(modifier = Modifier.padding(horizontal = 4.dp))
                    Text("Finalize Match Result")
                }
            }
        }
    }
}

@Composable
private fun ScoreRow(teamName: String, scoreText: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = teamName,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold
        )
        Text(
            text = scoreText,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddMatchSheet(
    teams: List<TeamEntity>,
    onDismiss: () -> Unit,
    onCreate: (teamA: String, teamB: String, venue: String, overs: Int) -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var teamA by remember { mutableStateOf(teams.getOrNull(0)?.name ?: "") }
    var teamB by remember { mutableStateOf(teams.getOrNull(1)?.name ?: "") }
    var venue by remember { mutableStateOf(teams.getOrNull(0)?.homeGround ?: "") }
    var oversText by remember { mutableStateOf("20") }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp)
                .padding(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "Schedule Match",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )

            OutlinedTextField(
                value = teamA,
                onValueChange = { teamA = it },
                label = { Text("Team A") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = teamB,
                onValueChange = { teamB = it },
                label = { Text("Team B") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = venue,
                onValueChange = { venue = it },
                label = { Text("Venue") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = oversText,
                onValueChange = { oversText = it.filter { ch -> ch.isDigit() } },
                label = { Text("Overs Limit") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Button(
                onClick = {
                    onCreate(teamA, teamB, venue, oversText.toIntOrNull() ?: 20)
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("Save Match")
            }
        }
    }
}
