package com.cricketmanager.app.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface CricketDao {

    @Transaction
    @Query("SELECT * FROM teams ORDER BY wins DESC, name ASC")
    fun observeTeamsWithPlayers(): Flow<List<TeamWithPlayers>>

    @Query("SELECT * FROM players ORDER BY runs DESC, wickets DESC, name ASC")
    fun observeAllPlayers(): Flow<List<PlayerEntity>>

    @Query("SELECT * FROM matches ORDER BY scheduledAt DESC")
    fun observeAllMatches(): Flow<List<MatchEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTeam(team: TeamEntity): Long

    @Query("DELETE FROM teams WHERE id = :teamId")
    suspend fun deleteTeamById(teamId: Long)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlayer(player: PlayerEntity): Long

    @Query("UPDATE players SET runs = runs + :deltaRuns WHERE id = :playerId")
    suspend fun addPlayerRuns(playerId: Long, deltaRuns: Int)

    @Query("UPDATE players SET wickets = wickets + 1 WHERE id = :playerId")
    suspend fun incrementPlayerWicket(playerId: Long)

    @Query("DELETE FROM players WHERE id = :playerId")
    suspend fun deletePlayerById(playerId: Long)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMatch(match: MatchEntity): Long

    @Update
    suspend fun updateMatch(match: MatchEntity)

    @Query("DELETE FROM matches WHERE id = :matchId")
    suspend fun deleteMatchById(matchId: Long)
}
