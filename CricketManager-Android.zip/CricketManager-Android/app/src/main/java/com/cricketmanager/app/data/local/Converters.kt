package com.cricketmanager.app.data.local

import androidx.room.TypeConverter

class Converters {
    @TypeConverter
    fun fromPlayerRole(role: PlayerRole): String = role.name

    @TypeConverter
    fun toPlayerRole(value: String): PlayerRole {
        return PlayerRole.entries.firstOrNull { it.name == value } ?: PlayerRole.BATTER
    }

    @TypeConverter
    fun fromMatchStatus(status: MatchStatus): String = status.name

    @TypeConverter
    fun toMatchStatus(value: String): MatchStatus {
        return MatchStatus.entries.firstOrNull { it.name == value } ?: MatchStatus.UPCOMING
    }
}
