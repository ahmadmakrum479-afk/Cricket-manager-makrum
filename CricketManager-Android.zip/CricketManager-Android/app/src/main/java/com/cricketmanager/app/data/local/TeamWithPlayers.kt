package com.cricketmanager.app.data.local

import androidx.room.Embedded
import androidx.room.Relation

data class TeamWithPlayers(
    @Embedded
    val team: TeamEntity,
    @Relation(
        parentColumn = "id",
        entityColumn = "teamId"
    )
    val players: List<PlayerEntity>
) {
    val sortedSquad: List<PlayerEntity>
        get() = players.sortedWith(
            compareByDescending<PlayerEntity> { it.isCaptain }.thenBy { it.jerseyNumber }
        )
}
