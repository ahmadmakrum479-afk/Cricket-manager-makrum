package com.cricketmanager.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import com.cricketmanager.app.ui.screens.CricketManagerApp
import com.cricketmanager.app.ui.theme.CricketManagerTheme
import com.cricketmanager.app.viewmodel.CricketViewModel
import com.cricketmanager.app.viewmodel.CricketViewModelFactory

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val app = application as CricketManagerApplication
        val factory = CricketViewModelFactory(app.repository)

        setContent {
            CricketManagerTheme {
                val viewModel: CricketViewModel = viewModel(factory = factory)
                CricketManagerApp(viewModel = viewModel)
            }
        }
    }
}
