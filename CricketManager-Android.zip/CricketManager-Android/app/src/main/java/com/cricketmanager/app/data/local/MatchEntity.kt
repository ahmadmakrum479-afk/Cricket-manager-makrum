package com.cricketmanager.app.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "matches")
data class MatchEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val teamAName: String,
    val teamBName: String,
    val venue: String,
    val oversLimit: Int = 20,
    val teamAScore: Int = 0,
    val teamAWickets: Int = 0,
    val teamAOvers: String = "0.0",
    val teamBScore: Int = 0,
    val teamBWickets: Int = 0,
    val teamBOvers: String = "0.0",
    val status: MatchStatus = MatchStatus.UPCOMING,
    val resultSummary: String = "",
    val scheduledAt: Long = System.currentTimeMillis()
)
